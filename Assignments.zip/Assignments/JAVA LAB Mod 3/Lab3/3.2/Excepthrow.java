
public class Excepthrow extends ValidateAge{
	Excepthrow(String text)
	{
		super(text);
	}

	public char[] getMessage() {
		// TODO Auto-generated method stub
		return null;
	}

}
