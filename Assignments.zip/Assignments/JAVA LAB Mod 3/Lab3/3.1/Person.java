
public class Person {
	public String fullName;
	public int l1;
	public int l2;
Person()
{
}
Person(String firstName,String lastName,char gender)
{
	fullName=firstName+lastName;
	l1=firstName.length();
	l2=lastName.length();
	try
	{
	if(l1==0 ||l2==0)
		throw new Exceptionthrow("First or last name must not be blank");
	}
	catch(Exceptionthrow e)
	{
		System.out.println(e.getMessage());
	}
}
public static void main(String []args)
{
	Person obj=new Person("XYZ","",'F');	
}
}
	
