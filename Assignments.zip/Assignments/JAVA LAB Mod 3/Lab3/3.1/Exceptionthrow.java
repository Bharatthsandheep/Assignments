
public class Exceptionthrow extends Exception
{
	Exceptionthrow(String msg)
	{
		super(msg);
	}
}
