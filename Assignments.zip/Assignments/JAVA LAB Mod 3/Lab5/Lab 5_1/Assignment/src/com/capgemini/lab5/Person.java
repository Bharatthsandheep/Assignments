package com.capgemini.lab5;

public class  Person {
	
	private String firstName;
	private String lastName; 

 
 public Person(String fname,String lname)  {
	 this.firstName=fname; 
	 this.lastName = lname; 
	 } 

 
 public String getFirstName(){
	 return this.firstName;
	 } 
 
 public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getLastName(){ 
	 return this.lastName;
	 }
 
}
 
 
