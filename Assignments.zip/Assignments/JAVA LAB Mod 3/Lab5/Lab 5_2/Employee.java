package com.capgemini.lab5;

import com.capgemini.lab5.exception.EmployeeException;

public class Employee {
	
	private int id;
	private String name;
	private double salary;
	
	public void setSalary(double salary) throws EmployeeException{
		if(salary<3000){
			throw new EmployeeException("Salary cannot be lesser then 3000");
		}
		this.salary = salary;
	}
	
	public double getSalary(){
		return salary;
	}

}
