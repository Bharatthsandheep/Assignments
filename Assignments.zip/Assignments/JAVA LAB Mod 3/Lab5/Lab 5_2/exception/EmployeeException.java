package com.capgemini.lab5.exception;

public class EmployeeException extends Exception {
		
	public EmployeeException(String message) {
		
		super(message);
	}
}
