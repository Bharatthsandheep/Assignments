
public class Person_main {

	public static void main(String[] args) {

		Person abc= new Person();
		abc.setFirstName("Divya");
		abc.setLastName("Bharti");
		abc.setGender("F");
		abc.setPhoneNumber("9874563215");
		abc.display();

	}

}
