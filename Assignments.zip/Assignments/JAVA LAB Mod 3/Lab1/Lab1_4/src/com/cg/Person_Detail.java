package com.cg;

public class Person_Detail 
{
		String FirstName;
		String LastName;
		String Gender;
		int age;
		double weight;
		
		void detail()
		{
			System.out.println("First Name: " +FirstName);
			System.out.println("Last Name: " +LastName);
			System.out.println("Gender: " +Gender);
			System.out.println("Age: " +age);
			System.out.println("Weight: " +weight);
		}
		
}

