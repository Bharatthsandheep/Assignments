package seleniumlab;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab6_11 {
	
    static WebDriver driver;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("https://demo.opencart.com/");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
	}	
	@Test
	public void test() throws InterruptedException {
	
		driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.linkText("Login")).click();
	    driver.findElement(By.id("input-email")).clear();
	    driver.findElement(By.id("input-email")).sendKeys("test123gh@test.com");
	    driver.findElement(By.id("input-password")).clear();
	    driver.findElement(By.id("input-password")).sendKeys("abcd1234");
	    driver.findElement(By.cssSelector("input.btn.btn-primary")).click();
	 
	    driver.findElement(By.linkText("Components")).click();
	    driver.findElement(By.linkText("Monitors (2)")).click();
	    new Select(driver.findElement(By.id("input-limit"))).selectByVisibleText("25");
	
	    driver.findElement(By.cssSelector("div.button-group > button[type=\"button\"]")).click();
	    driver.findElement(By.cssSelector("div.btn-group > button.btn.btn-default")).click();
	    driver.findElement(By.name("search")).click();
	    driver.findElement(By.name("search")).clear();
	    
	    
	    
	    driver.findElement(By.xpath("//a[@href='#tab-specification']")).click();
	
	    driver.findElement(By.xpath("//*[@id='content']/div[1]/div[2]/div[1]/button[1]")).click();
	    Thread.sleep(2000);

	    driver.findElement(By.xpath("//*[@id='search']/input")).sendKeys("Mobile");
	    driver.findElement(By.xpath("//*[@id='search']/span/button")).click();
	    driver.findElement(By.xpath("//*[@id='description']")).click();
	    driver.findElement(By.xpath("//*[@id='button-search']")).click();	    

	    driver.findElement(By.xpath("//*[@id='content']/div[3]/div[1]/div/div[2]/div[1]/h4/a")).click();
	    driver.findElement(By.id("input-quantity")).clear();
	    driver.findElement(By.id("input-quantity")).sendKeys("3");
	
	    driver.findElement(By.id("button-cart")).click();
	    Thread.sleep(2000);

	    driver.findElement(By.xpath("//*[@id='cart']/button")).click();	    
	    driver.findElement(By.xpath("//*[@id='cart']/ul/li[2]/div/p/a[2]")).click();
	    driver.findElement(By.xpath("//a[@title='My Account']")).click();
	    driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[5]/a")).click();
	    driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
	  }
		
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		driver.close();
	}

}
