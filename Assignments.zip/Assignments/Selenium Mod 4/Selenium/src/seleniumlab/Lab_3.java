package seleniumlab;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Lab_3 {

	static WebDriver driver;
	public static void main(String[] args) {
		
		driver=new FirefoxDriver();
		driver.get("http://demo.opencart.com");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		try
		{
			if(driver.getTitle().equals("Your Store"))
			{
				System.out.println("title verification passed");
			}
		}
		catch(NoSuchElementException e)
		{
			System.out.println("title verification failed");
		}
		driver.findElement(By.cssSelector("span.caret")).click();
		driver.findElement(By.linkText("Register")).click();
		try
		{
			if(driver.findElement(By.xpath("//div[@id='content']/h1")).isDisplayed())
			{
				System.out.println("passed");
			}
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Failed");
		}
		driver.findElement(By.cssSelector(".btn.btn-primary")).click();
		driver.switchTo().alert().accept();
		try
		{
			if(driver.findElement(By.cssSelector(".alert.alert-danger.alert-dismissible")).isDisplayed())
			{
				System.out.println("passed");
			}
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Failed");
		}
		
		 driver.findElement(By.id("input-firstname")).sendKeys("test");
		 
		 try
		 {
			 if(driver.findElement(By.id("input-firstname")).getSize().equals("33"))
					 {
				             System.out.println("Verified");
					 }
		 }
		 catch(NoSuchElementException e)
		 {
			 System.out.println("failed");
		 }
		
		 
		 driver.findElement(By.id("input-lastname")).sendKeys("test");
		 
		 try
		 {
			 if(driver.findElement(By.id("input-lastname")).getSize().equals("33"))
			 {
				 System.out.println("Verified");
			 }
		 }
		 catch(NoSuchElementException e)
		 {
			 System.out.println("failed");
		 }
		 
		
		 driver.findElement(By.id("input-email")).sendKeys("test123gh@test.com");
		 driver.findElement(By.id("input-telephone")).sendKeys("1234567890");
		 
		 driver.findElement(By.id("input-password")).sendKeys("abcd1234");
		 driver.findElement(By.id("input-confirm")).sendKeys("abcd1234");
		
		 driver.findElement(By.xpath("//*[@id='content']/form/fieldset[3]/div/div/label[1]/input")).click();
		 driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[1]")).click();
		 driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
		 if(driver.findElement(By.xpath("//*[@id='content']/h1")).isDisplayed())
		 {
			 System.out.println("passed");
		 }
		 else
		 {
			 System.out.println("failed");
		 }
		 driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
		 driver.findElement(By.linkText("View your order history")).click();
		 
		 
		

	}


		
		
		
		

	}


