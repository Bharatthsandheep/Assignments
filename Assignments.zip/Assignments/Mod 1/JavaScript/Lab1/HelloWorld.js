var msg
function sayHello(){
	msg=" Hello World";
	var result = msg.bold();
	return result;
}