var msg
function dispHello()
{
	msg=" Hello World";
	var result = msg.bold();
	return result;
//TODO:return the string “Hello World“
}
